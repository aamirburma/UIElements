//
//  DateTimePicker.swift
//  UIElements
//
//  Created by Aamir Burma on 17/06/21.
//

import UIKit

class DateTimePicker: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.addSubview(myDatePicker)
        view.addSubview(myLabel)
        // Do any additional setup after loading the view.
        
    }
    
    override func viewDidLayoutSubviews() {
        
        super.viewDidLayoutSubviews()
        self.view.backgroundColor = .systemTeal
        myLabel.frame = CGRect(x: 20, y: 40, width: view.frame.size.width - 40, height: 40)
        myDatePicker.frame = CGRect(x: 20, y: 100, width: view.frame.size.width - 40, height: 40)
    }
    
    private let myDatePicker:UIDatePicker = {
        let datePicker = UIDatePicker()
        datePicker.datePickerMode = .dateAndTime
        datePicker.backgroundColor = .systemYellow
        datePicker.timeZone = TimeZone(secondsFromGMT: 0)
        datePicker.addTarget(self, action: #selector(handleDateChange), for: .valueChanged)
        return datePicker
    }()
    
    private let myLabel:UILabel = {
        let myLabel = UILabel()
        myLabel.text = "Choose your date"
        myLabel.textAlignment = .center
        myLabel.backgroundColor = .systemFill
        return myLabel
    }()
    
    @objc func handleDateChange(){
//        print(myDatePicker.date)
        let startingDate = Date()
//        print(startingDate)
//        print(startingDate - myDatePicker.date)
        let components = Calendar.current.dateComponents([.weekOfYear, .month], from: myDatePicker.date, to: startingDate)
    let msg = "difference is \(components.month ?? 0) days and \(components.month ?? 0) months and \(components.weekOfYear ?? 0) weeks"
        myDatePicker.isHidden = true
        myLabel.text = msg
        
//        print(components)

    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
