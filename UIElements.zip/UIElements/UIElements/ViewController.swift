//
//  ViewController.swift
//  UIElements
//
//  Created by Aamir Burma on 17/06/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .systemBlue
        // Do any additional setup after loading the view.
        view.addSubview(myLabel)
        view.addSubview(myTextField)
        view.addSubview(myButton)
        view.addSubview(myButton2)
        
        view.addSubview(mySwitch)
        view.addSubview(myButton3)
        view.addSubview(myButton4)
    }
    
    /** Label */
    private let myLabel:UILabel = {
        let label = UILabel()
        label.text = "Your name will display here"
        label.textAlignment = .center
        label.backgroundColor = .systemFill
        return label
    }()
    
    /** Text Field*/
    private let myTextField:UITextField = {
        let myTextField = UITextField()
        myTextField.placeholder = "Enter your name"
        myTextField.textAlignment = .center
        myTextField.borderStyle = .roundedRect
        myTextField.backgroundColor = .systemFill
        return myTextField
    }()
    
    /** Button */
    private let myButton:UIButton = {
        let myButton = UIButton()
        myButton.setTitle("Confirm", for: .normal)
        myButton.addTarget(self, action: #selector(addName), for: .touchUpInside)
        myButton.backgroundColor = .systemGreen
        myButton.layer.cornerRadius = 6
       return myButton
    }()
    
    /** Switch */
    
    private let mySwitch:UISwitch = {
        let switcher = UISwitch()
        switcher.addTarget(self, action: #selector(handleSwitch), for: .valueChanged)
        return switcher
    }()
    
    /** Button 2*/
    private let myButton2:UIButton = {
        let myButton2 = UIButton()
        myButton2.setTitle("Date and Time Picker ->", for: .normal)
        myButton2.addTarget(self, action: #selector(loadDateTime), for: .touchUpInside)
        myButton2.backgroundColor = .systemRed
        myButton2.layer.cornerRadius = 6
       return myButton2
    }()
    
    /** Button 3*/
    private let myButton3:UIButton = {
        let myButton3 = UIButton()
        myButton3.setTitle("<- Image with opacity controller", for: .normal)
        myButton3.addTarget(self, action: #selector(loadImageOpacity), for: .touchUpInside)
        myButton3.backgroundColor = .systemRed
        myButton3.layer.cornerRadius = 6
       return myButton3
    }()
    /** Button 4*/
    private let myButton4:UIButton = {
        let myButton4 = UIButton()
        myButton4.setTitle("ToolBar", for: .normal)
        myButton4.addTarget(self, action: #selector(loadToolBar), for: .touchUpInside)
        myButton4.backgroundColor = .systemRed
        myButton4.layer.cornerRadius = 6
       return myButton4
    }()
    
    /** Add name on button click*/
    @objc func addName(){
        myLabel.text = "Your Name is \(myTextField.text!)"
    }
    
    @objc func handleSwitch() {
        print(mySwitch.isOn)
        if(mySwitch.isOn){
            view.backgroundColor = .systemGray
        }else{
            view.backgroundColor = .systemTeal
        }
        
    }
    /** Load */
    
    @objc func loadDateTime(){
        
        print("Clicked!")
        let vc = DateTimePicker()
        self.present(vc, animated: true)
        navigationController?.pushViewController(vc, animated: true)
    }
    /** Load */
    
    @objc func loadToolBar(){
        
        print("Clicked!")
        let vc = ToolBarVC()
        self.present(vc, animated: true)
        navigationController?.pushViewController(vc, animated: true)
    }
    /** Load */
    
    @objc func loadImageOpacity(){
        
        print("Clicked!")
        let vc = ImageOpacityVC()
        self.present(vc, animated: true)
        navigationController?.pushViewController(vc, animated: true)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        myLabel.frame = CGRect(x: 20, y: 80, width: view.frame.size.width - 40, height: 40)
        myTextField.frame = CGRect(x: 20, y: 140, width: view.frame.size.width - 40, height: 40)
        myButton.frame = CGRect(x: 40, y: 200, width: view.frame.size.width - 80, height: 60)
        myButton2.frame = CGRect(x: 40, y: 280, width: view.frame.size.width - 80, height: 60)
        myButton3.frame = CGRect(x: 40, y: 360, width: view.frame.size.width - 80, height: 60)
        myButton4.frame = CGRect(x: 40, y: 440, width: view.frame.size.width - 80, height: 60)
        
        mySwitch.frame = CGRect(x: 20, y: 520, width: view.frame.size.width - 80, height: 40)
    }
}

