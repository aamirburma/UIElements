//
//  ImageOpacityVC.swift
//  UIElements
//
//  Created by Aamir Burma on 20/06/21.
//

import UIKit

class ImageOpacityVC: UIViewController {

    override func viewDidLoad() {
        title = "Image Opacity"
        super.viewDidLoad()
        view.backgroundColor = .systemPink
        view.addSubview(myImageView)
        view.addSubview(mySlider)
        view.addSubview(myLabel)
        view.addSubview(myPageControl)
        // Do any additional setup after loading the view.
    }
    
    override func viewDidLayoutSubviews() {
            super.viewDidLayoutSubviews()
            myImageView.frame = CGRect(x: 20, y: 20, width:  250, height: 200)
        
        mySlider.frame = CGRect(x: 20, y: myImageView.frame.origin.y + myImageView.frame.size.height, width: view.frame.size.width - 40, height: 40)
        myLabel.frame = CGRect(x: 20, y: mySlider.frame.origin.y + mySlider.frame.size.height, width: view.frame.size.width - 40, height: 40)
        
        myPageControl.frame = CGRect(x: 20, y: (myLabel.frame.origin.y + myLabel.frame.size.height) + 40, width: view.frame.size.width - 40, height: 40)
//            myProgressView.frame = CGRect(x: 20, y: myImageView.bottom + 20, width: view.width - 40, height: 40)
    }
    
    
    
    private let myPageControl:UIPageControl = {
        let pageControl = UIPageControl()
        pageControl.numberOfPages = 3
        pageControl.backgroundStyle = .prominent
        pageControl.addTarget(self, action: #selector(handlePageControl), for: .valueChanged)
        return pageControl
    }()
    
    // Image View
    private let myImageView:UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.image = UIImage(named: "iosImage")
        return imageView
    }()
    // Image View
    private let mySlider:UISlider = {
        let mySlider = UISlider()
        mySlider.minimumValue = 0
        mySlider.maximumValue = 10
        mySlider.addTarget(self, action: #selector(handleSlider), for: .valueChanged)
        return mySlider
    }()

    @objc func handleSlider() {
        print(mySlider.value)
        myLabel.text = "Image opacity \(mySlider.value)"
        myImageView.alpha = CGFloat(mySlider.value / 10)
    }
    @objc func handlePageControl() {
        print(myPageControl.currentPage)
        if(myPageControl.currentPage == 1){
            myImageView.image = UIImage(named: "ios2")
        }else{
            myImageView.image = UIImage(named: "iosImage")
        }
    }
    
    /** Label */
    private let myLabel:UILabel = {
        let label = UILabel()
        label.text = "Opacity of Image: 1"
        label.textAlignment = .center
        label.backgroundColor = .systemFill
        return label
    }()
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
