//
//  ToolBarVC.swift
//  UIElements
//
//  Created by Aamir Burma on 21/06/21.
//

import UIKit

class ToolBarVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemPurple
        view.addSubview(toolBar)
        // Do any additional setup after loading the view.
    }

    // ToolBar
    private let toolBar:UIToolbar = {
        let toolBar = UIToolbar()
        let cancel = UIBarButtonItem(barButtonSystemItem: .close, target: self, action: #selector(handleCancel))
//        let spacer = UIBarButtonItem(systemItem: .flexibleSpace)
//        let gallery = UIBarButtonItem(barButtonSystemItem: .organize, target: self, action: #selector(handleGallery))
//        let camera = UIBarButtonItem(barButtonSystemItem: .camera, target: self, action: #selector(handleCamera))
//        toolBar.items = [cancel, spacer, gallery, camera]
        return toolBar
    }()

    @objc private func handleCancel() {
       self.dismiss(animated: true)
   }

    /*@objc private func handleGallery() {
       print("gallery called")
       imagePicker.sourceType = .photoLibrary
       DispatchQueue.main.async {
           self.present(self.imagePicker, animated: true)
       }
   }*/

    override func viewDidLayoutSubviews() {
            super.viewDidLayoutSubviews()
        let toolBarHeight:CGFloat = view.safeAreaInsets.top + 40
        toolBar.frame = CGRect(x: 0, y: 0, width: view.frame.size.width, height: toolBarHeight)

//        let tabBarHeight:CGFloat = view.safeAreaInsets.bottom + 49
//        tabBar.frame = CGRect(x: 0, y: view.height - tabBarHeight, width: view.width, height: tabBarHeight)
//
//        myImageView.frame = CGRect(x: 20, y: toolBar.bottom + 40, width: view.width - 40, height: 200)
    }
/*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
